import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace skillmatrixui.controller
 */
export default class App extends Controller {

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {

    }
}